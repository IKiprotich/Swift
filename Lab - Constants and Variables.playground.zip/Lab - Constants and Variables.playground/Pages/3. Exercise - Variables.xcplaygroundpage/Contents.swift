/*:
## Exercise - Variables
 
 Declare a variable `schooling` and set it to the number of years of school that you have completed. Print `schooling` to the console.
 */
var schooling = 16
print(schooling)

schooling = 17
print(schooling)


//:  Does the above code compile? Why is this different than trying to update a constant? Print your explanation to the console using the `print` function.
print("This is because for the constant, you have to redeclare it but in variables it infers already that it is a variable")

/*:
[Previous](@previous)  |  page 3 of 10  |  [Next: App Exercise - Step Count](@next)
 */
