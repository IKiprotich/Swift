/*:
## Exercise - Return Values

 Write a function called `greeting` that takes a `String` argument called name, and returns a `String` that greets the name that was passed into the function. I.e. if you pass in "Sophie" the return value might be "Hi, Sophie! How are you?" Use the function and print the result.
 */
func greeting(name:String)-> String{
    let result = "Hi, \(name)! How are you?"
    return result
}

print(greeting(name: "Ian"))

//:  Write a function that takes two `Int` arguments, and returns an `Int`. The function should multiply the two arguments, add 2, then return the result. Use the function and print the result.
func arith(Num1:Int, Num2:Int) -> Int{
    let result = (Num1 * Num2) + 2
    return result
}
print(arith(Num1: 4, Num2: 5))
/*:
[Previous](@previous)  |  page 5 of 6  |  [Next: App Exercise - Separating Functions](@next)
 */
